<?php
/**
 * The front page template file
 *
 * If the user has selected a static page for their homepage, this is what will
 * appear.
 * Learn more: https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */

get_header(); ?>


	<!-- HERO 
	================================================== --> 	
    <div class="hero">
    <div class="outter">
      <div class="inner">
        <div class="hero-content">
          <div class="container">
              <h1 class="hero-title">Become a <br>Business <img src="<?php bloginfo('template_url'); ?>/img/star.png" width="10%"/> </h1>
              <p class="hero-text">Everything in our life started with an idea. Ideas then grow, getting bigger and bigger, <br>
              took physical shapes then considered as <span class="element" data-text1="Achievements." data-text2="Organizations." data-text3="Corporations." data-loop="true" data-backdelay="3000"></span> <br>We Give You The Start.</p>
                  <svg class="down-arrow" xmlns="http://www.w3.org/2000/svg" width="14.486" height="18.412" viewBox="0 0 14.486 18.412">
                    <path d="M7.073,26.241h0L0,19.172l1.414-1.415,4.829,4.829V8h2V22.586l4.829-4.829,1.415,1.415-7.241,7.24Z" transform="translate(0 -8)"/>
                  </svg>
          </div>
        </div>
      </div>
    </div>
    <div id="particles-js"></div>
    <div class="hero-image"></div>
  </div>


<!-- PORTFOLIO SECTION
================================================== --> 
<section id="portfolio" class="portfolio atop"> 

  <!-- Portfolio Filter -->


  <!-- filter icon for mobile-->
  <div class="filter-icon d-none">
    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" x="0" y="0" width="18" height="20" viewBox="296.5 494.5 20 20" enable-background="new 296.5 494.5 20 20" xml:space="preserve">
      <path fill="black" fill-rule="evenodd" clip-rule="evenodd" d="M296.5 494.5h8v8h-8V494.5z"></path>
      <path fill="black" fill-rule="evenodd" clip-rule="evenodd" d="M308.5 494.5h8v8h-8V494.5z"></path>
      <path fill="black" fill-rule="evenodd" clip-rule="evenodd" d="M296.5 506.5h8v8h-8V506.5z"></path>
      <path fill="black" fill-rule="evenodd" clip-rule="evenodd" d="M308.5 506.5h8v8h-8V506.5z"></path>
    </svg>
  </div>

  <div class="container">
    <div class="row masonry clearfix">
        <!-- a work -->
        <a href="http://localhost/just/marketing-planning-and-strategies/" class="col-xl-6 col-md-6 grid-item digital"  data-type="ajax-load">
            <figure class="portfolio-item">                 
                <div class="image" style="background-image: url(<?php bloginfo('template_url'); ?>/img/works/work-1/01.jpg);">     
                    <img src="<?php bloginfo('template_url'); ?>/img/works/work-1/01.jpg"/>
                </div>
                <figcaption>
                  
                    <h3 class="title">Marketing Planning & Strategies</h3>
                </figcaption> 
            </figure>
          </a>

      <!-- a work -->
      <a href="http://localhost/just/creative-advertising/" class="col-lg-5 col-md-5 grid-item video"  data-type="ajax-load">
        <figure class="portfolio-item">                 
          <div class="image" style="background-image: url(<?php bloginfo('template_url'); ?>/img/works/work-1/ca1.jpg);">     
              <img src="<?php bloginfo('template_url'); ?>/img/works/work-1/ca1.jpg"/>
          </div>
          <figcaption>
            
              <h3 class="title">Creative Advertising </h3>
          </figcaption> 
      </figure>
        </a>  
          
          <!-- a work -->
          <a href="http://localhost/just/graphic-design-media-production/" class="col-lg-5 col-md-5 grid-item brandings"  data-type="ajax-load">
              <figure class="portfolio-item">            
                <div class="image" style="background-image: url(<?php bloginfo('template_url'); ?>/img/works/work-1/gv1.jpg);">     
                    <img src="<?php bloginfo('template_url'); ?>/img/works/work-1/gv1.jpg"/>
                </div>
                <figcaption>
                 
                    <h3 class="title">Graphic Design & Media Production</h3>
                </figcaption> 
              </figure>
            </a> 
          
        <!-- a work -->
        <a href="http://localhost/just/hr-development/" class="col-lg-6 col-md-6 grid-item brandings"  data-type="ajax-load">
            <figure class="portfolio-item">                 
              <div class="image" style="background-image: url(<?php bloginfo('template_url'); ?>/img/works/work-1/hr1.jpg);">     
                  <img src="<?php bloginfo('template_url'); ?>/img/works/work-1/hr1.jpg"/>
              </div>
              <figcaption>
              
                  <h3 class="title">HR Development</h3>
              </figcaption> 
            </figure>
          </a> 
          
      <!-- a work -->
      <a href="http://localhost/just/strategic-management-for-small-business/" class="col-lg-5 col-md-5 grid-item digital"  data-type="ajax-load">
          <figure class="portfolio-item">                 
            <div class="image" style="background-image: url(<?php bloginfo('template_url'); ?>/img/works/work-1/stra1.jpg);">     
                <img src="<?php bloginfo('template_url'); ?>/img/works/work-1/stra1.jpg"/>
            </div>
            <figcaption>
            
                <h3 class="title">Strategic Management for Small Business</h3>
            </figcaption> 
          </figure>
        </a>  

        <a href="http://localhost/just/business-success-enhancement-capsules/" class="col-lg-6 col-md-6 grid-item digital"  data-type="ajax-load">
          <figure class="portfolio-item">                 
          <div class="image" style="background-image: url(<?php bloginfo('template_url'); ?>/img/works/work-1/uniq1.jpg);">    
                <img src="<?php bloginfo('template_url'); ?>/img/works/work-1/uniq1.jpg"/>
            </div>
            <figcaption>
            
                <h3 class="title">Our unique service “Business Success Enhancement Capsules”</h3>
            </figcaption> 
          </figure>
        </a>  

        <a href="http://localhost/just/application-development/" class="col-lg-6 col-md-6 grid-item digital"  data-type="ajax-load">
          <figure class="portfolio-item">                 
          <div class="image" style="background-image: url(<?php bloginfo('template_url'); ?>/img/works/work-1/app1.jpg);">    
                <img src="<?php bloginfo('template_url'); ?>/img/works/work-1/app1.jpg"/>
            </div>
            <figcaption>
            
                <h3 class="title">Application Development</h3>
            </figcaption> 
          </figure>
        </a>  

        
  </div> <!-- container end -->
</section>

<section class="services padding_120">
  <div class="container">
    <div class="section-title bottom_90">
      <span>About</span>
      <h2 class="title">We are focused on customer's growth and development. <br> We do it with attention to detail.</h2>
    </div>
    <div class="row">
      <!-- a service-->
      <div class="col-lg-6 col-md-6" data-type="ajax-load" style="animation: bounceInLeft 10s;"> 
                <img src="<?php bloginfo('template_url'); ?>/img/about.jpg" class="img-responsive fit-image animate__animated animate__fadeInUp" alt="whoarewe" />
      </div>
      <div class="col-lg-6 col-md-6" data-type="ajax-load" style="animation: bounceInRight 10s;">
       
<p>We’re exposed to thousands of commercial messages a day. Hundreds of hours of video will be uploaded by the time you finish this sentence. Social media has changed everything we knew about the ways brands should behave. Today’s world is loud and fast. To succeed, marketing plans need more than traditional solutions.</p>
<br>
<p>More than a traditional communications agency, <b>JUST IDEAS</b> operates as a consultancy, working closely with marketing teams in order to build sound strategic solutions to address complex business problems. As an award-winning agency, we engage deeply with strategic challenges, and only when we’ve identified that one key element pivotal to success, then we develop and execute brand communication and advertising.</p>
</div>

      </div>
     
      
    </div>
    </section>



 

         
         
	<?php
    if ( have_posts() ) :
        while ( have_posts() ) :
            the_post();
            //
            // Post Content here
            //
        endwhile; // end while
    endif; // end if
?>

	

	

<?php get_footer();?>
